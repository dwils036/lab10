/*David Wilson dwils036@ucr.edu
 * Partner: Hector Soto Jr
 *Lab Section: 023
 * Assignment: Lab 10 exercise 1
 *Blinking lights/Different Periods
 *
 *I acknowledge all content contained herein, excluding template or example code, 
 *is my own original work
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>

volatile unsigned char TimerFlag = 0; 
unsigned long _avr_timer_M = 1; 
unsigned long _avr_timer_cntcurr = 0; 


void TimerSet(unsigned long M) {
	_avr_timer_M = M;
	_avr_timer_cntcurr = _avr_timer_M;
}

void TimerOn() {
	
	TCCR1B 	= 0x0B;	
	
	OCR1A 	= 125;

	TIMSK1 	= 0x02;

	TCNT1 = 0;
	
	_avr_timer_cntcurr = _avr_timer_M;

	SREG |= 0x80;	// 0x80=1000000
}

void TimerOff() {
	TCCR1B 	= 0x00; // 0x00=off
}

void TimerISR() {
	TimerFlag = 1;
}
ISR(TIMER1_COMPA_vect)
{
	_avr_timer_cntcurr--; 			
	if (_avr_timer_cntcurr == 0) { 	
		TimerISR(); 				
		_avr_timer_cntcurr = _avr_timer_M;
	}
}
unsigned char output3LEDS;
unsigned char outputBlinkLEDS;

enum ThreeStateMachine{threeLEDS, State1, State2, State3} state3LEDS;
enum BlinkingStateMachine{blinkingLED, ON, OFF} stateBlinkLED;
enum CombineStateMachine{combineLEDS} stateComLEDS;

void ThreeLEDs() 
{
	switch(state3LEDS)
	{               // Transitions
		case threeLEDS:
		state3LEDS = State1;
		break;
		case State1:
		state3LEDS = State2;
		break;
		case State2:
		state3LEDS = State3;
		break;
		case State3:
		state3LEDS = State1;
		break;
		default:
		break;
	}
	switch(state3LEDS)
	{               // Actions
		case threeLEDS:
		output3LEDS = 0x00;
		break;
		case State1:
		output3LEDS = 0x01;
		break;
		case State2:
		output3LEDS = 0x02;
		break;
		case State3:
		output3LEDS = 0x04;
		break;
		default:
		break;
	}
}
void BlinkingLEDs() // B3
{
	switch(stateBlinkLED)
	{               // Transitions
		case blinkingLED:
		stateBlinkLED = ON;
		break;
		case ON:
		stateBlinkLED = OFF;
		break;
		case OFF:
		stateBlinkLED = ON;
		break;
		default:
		break;
	}
	switch(stateBlinkLED)
	{               // Actions
		case blinkingLED:
		outputBlinkLEDS = 0x00;
		break;
		case ON:
		outputBlinkLEDS = 0x08;
		break;
		case OFF:
		outputBlinkLEDS = 0x00;
		break;
		default:
		break;
	}
}
void CombineLEDs()
{
	switch(stateComLEDS)
	{               // Transitions
		case combineLEDS:
		break;
		default:
		break;
	}
	switch(stateComLEDS)
	{               // Actions
		case combineLEDS:
		PORTB = output3LEDS | outputBlinkLEDS;
		break;
		default:
		break;
	}
}

int main(void)
{
	DDRB = 0xFF; PORTB = 0x00;
	
	TimerSet(100);
	TimerOn();

	unsigned long threeLEDS__Time = 0;
	unsigned long blinkingLEDS_Time = 0;
	
	state3LEDS = threeLEDS;
	stateBlinkLED = blinkingLED;
	stateComLEDS = combineLEDS;

	while (1)
	{
		if(threeLEDS__Time >= 300){
			ThreeLEDs();
			threeLEDS__Time = 0;
		}
		if(blinkingLEDS_Time >= 1000){
			BlinkingLEDs();
			blinkingLEDS_Time = 0;
		}
		CombineLEDs();
		while(!TimerFlag){}
		TimerFlag = 0;
		threeLEDS__Time += 100;
		blinkingLEDS_Time += 100;
	}
}